@extends('layouts.main')
@section('title', 'Home')
@section('artikel')
    <h1> Welcome to Liquid Dynasty </h1>
    <p> Liquid Dynasty memiliki banyak jenis dan kebutuhan minuman yang customer butuhkan. </p>
@endsection