<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('artikel'); ?>
    <h1> Welcome to Liquid Dynasty </h1>
    <p> Liquid Dynasty memiliki banyak jenis dan kebutuhan minuman yang customer butuhkan. </p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\##SEM 4\Pak Katon\liquid\resources\views/home.blade.php ENDPATH**/ ?>