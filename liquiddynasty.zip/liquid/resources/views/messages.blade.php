@extends('layouts.main')
@section('title', 'Messages')
@section('artikel')
    <h1> MESSAGES </h1>
    <p> Ini adalah Messages </p>
@endsection