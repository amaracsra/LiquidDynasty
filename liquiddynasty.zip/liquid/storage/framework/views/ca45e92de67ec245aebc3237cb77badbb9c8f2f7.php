<?php $__env->startSection('title', 'Form Add Drink'); ?>
<?php $__env->startSection('artikel'); ?>
    <div class="card">
        <div class="card-header"></div>
        <div class="card-body">
            
            <form action="/save" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label> Merek </label>
                    <input type="text" name="merek" class="form-control" required>
                </div>
                <div class="form-group">
                    <label> Distributor </label>
                    <input type="text" name="distributor" class="form-control" required>
                </div>
                <div class="form-group">
                    <label> Stok </label>
                    <input type="number" min="0" max="10000" name="stok" class="form-control" required>
                </div>
                <div class="form-group">
                    <label> Foto </label>
                    <input type="file" name="foto" class="form-control-file" accept="image/*">
                </div>
                <div class="form-control">
                    <button type="submit" class="btn btn-primary">SIMPAN</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\##SEM 4\Pak Katon\liquid\resources\views/form-add.blade.php ENDPATH**/ ?>