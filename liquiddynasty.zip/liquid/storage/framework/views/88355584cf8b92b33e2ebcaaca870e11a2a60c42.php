<?php $__env->startSection('title', 'Messages'); ?>
<?php $__env->startSection('artikel'); ?>
    <h1> MESSAGES </h1>
    <p> Ini adalah Messages </p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\##SEM 4\Pak Katon\liquid\resources\views/messages.blade.php ENDPATH**/ ?>