<?php $__env->startSection('title', 'Drink'); ?>
<?php $__env->startSection('artikel'); ?>
    <div class="card-header">
        <a href="/drink/add-form" class="btn btn-primary"><i class="bi bi-file-plus-fill"></i> ADD DRINK </a>
    </div>
    <div class="card-body">
        <?php if(session('alert')): ?>
            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                <strong><?php echo e(session('alert')); ?></strong>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>

        <table id="example" class="display" style="width:100%">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Merek</th>
                    <th>Distributor</th>
                    <th>Stok</th>
                    <th>Foto</th>
                    <th> Aksi </th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $mv; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx => $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($idx + 1); ?></td>
                        <td><?php echo e($m->merek); ?></td>
                        <td><?php echo e($m->distributor); ?></td>
                        <td><?php echo e($m->stok); ?></td>
                        <td>
                            <img src="<?php echo e(asset('/storage/'.$m->foto)); ?>" alt="<?php echo e($m->foto); ?>" height="80" width="80">
                        </td>
                        <td>
                            <a href="/drink/edit-form/<?php echo e($m->id); ?>" class="btn btn-success"><i class="bi bi-pencil-square"></i></a>
                            <a href="/delete/<?php echo e($m->id); ?>" class="btn btn-danger"><i class="bi bi-trash3"></i></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\##SEM 4\Pak Katon\liquid\resources\views/drink.blade.php ENDPATH**/ ?>