@extends('layouts.main')
@section('title', 'Settings')
@section('artikel')
    <h1> SETTINGS </h1>
    <p> Ini adalah Home </p>
@endsection